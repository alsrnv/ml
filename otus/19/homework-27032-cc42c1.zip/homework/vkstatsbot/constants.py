START_COMMAND_TEXT = "Hello! My name is VKStatBot. " \
                     "Send me a link to VK profile or group and " \
                     "I will show you some statistics"
NOT_A_VK_LINK = "Seems like it is not a vk.com profile or group link. " \
                "Try again, please."
ERROR = "Ooops! Error occurred, try again later."
